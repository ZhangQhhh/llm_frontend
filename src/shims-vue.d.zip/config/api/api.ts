export const API_BASE_URL = process.env.VUE_APP_API_BASE_URL;
export const LLM_BASE_URL = process.env.VUE_APP_LLM_BASE_URL;
export const SHOW_HIDDEN_NODES = process.env.VUE_APP_SHOW_HIDDEN_NODES === 'true';
export const MCQ_BASE_URL = process.env.VUE_APP_MCQ_BASE_URL;
export const WRITER_BASE_URL = process.env.VUE_APP_WRITER_URL || LLM_BASE_URL;
export const STREAM_TEST_URL = process.env.VUE_APP_STREAM_TEST_URL;
// OCR服务URL
export const OCR_BASE_URL = process.env.VUE_APP_OCR_BASE_URL || 'http://53.3.1.2:9000';

// 数研报告API前缀：从环境变量读取
export const DAV_PREFIX = process.env.VUE_APP_DAV_PREFIX || '';

// 公文写作助手（official_document）服务URL
export const OFFDO_BASE_URL = process.env.VUE_APP_OFFDO_BASE_URL || '/offdo';

// 定义所有API端点
export const API_ENDPOINTS = {
  ADMIN: {
    USERS: `/admin/users`,
    USER_LIST: `/api/admin/users/list/`,
    USER_LOGIN_IPS: `/api/admin/users/login-ips/`,
    USER_BAN: `/api/admin/users/ban/`,
    USER_UNBAN: `/api/admin/users/unban/`,
    // 账号审核
    PENDING_USERS: `/api/admin/users/pending/`,
    APPROVE_USER: `/api/admin/users/approve/`,
    REJECT_USER: `/api/admin/users/reject/`,
    // 分组权限管理
    GROUPS_LIST: `/api/admin/groups`,
    GROUPS_CREATE: `/api/admin/groups`,
    GROUPS_DETAIL: (groupId: string | number) => `/api/admin/groups/${groupId}`,
    GROUPS_PERMISSIONS: (groupId: string | number) => `/api/admin/groups/${groupId}/permissions`,
    GROUPS_USER_UPDATE: (userId: string | number) => `/api/admin/groups/users/${userId}`,
    // 题库管理
    IMPORT_TEMPLATE: '/admin/import_template/public_file',
    EXPORT_TEACHER_DOCX: '/admin/export_teacher_docx',
    EXPORT_SCORES_ZIP: '/admin/export_scores_zip',
    EXPORT_SCORES_DOCX: '/admin/export_scores_docx',
  },
  SUPER_ADMIN: {
    CREATE_ADMIN: `/api/admin/create-admin/`,
    LIST_ADMINS: `/api/admin/list-admins/`,
    DOWNGRADE_ADMIN: `/api/admin/downgrade-admin/`,
    RESET_ADMIN_PASSWORD: `/api/admin/reset-admin-password/`,
    UPGRADE_ADMIN: `/api/admin/upgrade-admin/`,
    UPDATE_USERNAME: `/api/admin/users/update-username/`,
    UPDATE_ID_CARD_NUMBER: `/api/admin/users/update-id-card-number/`,
    UPDATE_POLICE_ID: `/api/admin/users/update-police-id/`,
    SET_BJZX_ADMIN: `/api/admin/users/set-bjzx-admin/`,  // 设置边检智学管理员
    IP_BLACKLIST_LIST: `/api/admin/ip-blacklist/`,
    IP_BLACKLIST_ADD: `/api/admin/ip-blacklist/`,
    IP_BLACKLIST_DELETE: (identifier: string | number) => `/api/admin/ip-blacklist/${encodeURIComponent(String(identifier))}/`,
    BACKUP_FILES: `/api/admin/backup/files`,
    BACKUP_PREVIEWS: `/api/admin/backup/previews`,
    BACKUP_PREVIEW_TABLES: (previewId: string) => `/api/admin/backup/previews/${encodeURIComponent(previewId)}/tables`,
    BACKUP_PREVIEW_TABLE: (previewId: string, tableName: string) => `/api/admin/backup/previews/${encodeURIComponent(previewId)}/tables/${encodeURIComponent(tableName)}`,
    BACKUP_RESTORE: `/api/admin/backup/restore`,
    BACKUP_PREVIEW_DELETE: (previewId: string) => `/api/admin/backup/previews/${encodeURIComponent(previewId)}`,
  },
  USER: {
    LOGIN: `/user/account/token/`,
    REGISTER: `/user/account/register/`,
    INFO: `/user/account/info/`,
    SYNC_LOGIN_IP: `/user/account/login-ip/`
  },
  PERMISSIONS: {
    LIST: `/user/permissions`,
    CHECK: `/permission/check`
  },
  // 知识问答相关API
  KNOWLEDGE: {
    // 单轮对话（无会话）- 使用完整URL（用于fetch流式请求）
    CHAT: `${LLM_BASE_URL}/knowledge_chat`,
    CHAT_12367: `${LLM_BASE_URL}/knowledge_chat_12367`,
    CONVERSATION_CHAT: `${LLM_BASE_URL}/knowledge_chat_conversation`,
    STREAM_TEST: STREAM_TEST_URL || '',
    // MCQ策略判断 - 使用完整URL
    MCQ_STRATEGY: `${LLM_BASE_URL}/mcq_strategy`,
    // MCQ格式化 - 使用完整URL
    MCQ_FORMAT: `${LLM_BASE_URL}/mcq_format`,
    // MCQ答案总结 - 使用完整URL
    MCQ_SUMMARIZE: `${LLM_BASE_URL}/mcq_summarize`,
    // 会话管理 - 使用相对路径（用于llmHttp）
    CONVERSATION_NEW: `/conversation/new`,
    CONVERSATION_CLEAR: `/conversation/clear`,
    CONVERSATION_STATISTICS: `/conversation/statistics`,
    CONVERSATION_SESSIONS_LIST: `/conversation/sessions/list`,
    CONVERSATION_SESSION_HISTORY: (sessionId: string) => `/conversation/sessions/${sessionId}/history`,
    CONVERSATION_SESSION_INFO: (sessionId: string) => `/conversation/sessions/${sessionId}/info`,
    CONVERSATION_SESSION_DELETE: (sessionId: string) => `/conversation/sessions/${sessionId}/delete`,
    CONVERSATION_CACHE_CLEAR: `/conversation/cache/clear`,
  },
  // 反馈相关API（在 3000 端口的主后端，通过nginx转发）
  FEEDBACK: {
    LIKE: `/feedback/like`,
    DISLIKE: `/feedback/dislike`,
    LIST: `/feedback/show/list`,
    PAGE: `/feedback/show/page`,
    DETAIL: (feedbackId: string | number) => `/feedback/show/${feedbackId}`,
  },
  // 认证相关API
  AUTH: {
    CHANGE_PASSWORD: `/auth/change_password`,
    RESET_PASSWORD: `/auth/reset_password`,
    CHANGE_NAME: `/auth/change_username`,
    USER_INFO: `/auth/user-info`,
    FORGET_PASSWORD: '/auth/forget'
  },
  // 题库管理API
  QUESTIONS: {
    UPLOAD: '/questions/upload',
    EXPLAIN: '/questions/explain',
    REVIEW: '/questions/review',
    REJECT: '/questions/reject',
    APPROVE_ALL: '/questions/approve_all',
    DEBUG_QUESTIONS: '/debug/questions',
    DEBUG_ANALYSES: '/debug/analyses',
  },
  // 试卷管理API
  PAPERS: {
    LIST_OPEN: '/papers/list_open',
    LIST_ALL: '/papers/list_all',
    VIEW: '/papers/view',
    CREATE: '/papers/create',
  },
  // 考试相关API
  EXAM: {
    START: '/exam/start',
    SUBMIT: '/exam/submit',
    REVIEW: '/exam/review',
    // 考试发布相关
    PUBLISH: '/exam/publish',           // 发布考试
    PUBLISHED_LIST: '/exam/published',   // 获取已发布考试列表
    CANCEL: '/exam/cancel',             // 取消已发布考试
    NOTIFICATIONS: '/exam/notifications', // 获取考试通知（学生端）
    GRADES_STATS: '/exam/grades_stats',  // 获取成绩统计数据
  },
  // 学生端API
  STUDENT: {
    EXPORT_MY_REPORT_DOCX: '/student/export_my_report_docx',
  },
  // 公开API
  PUBLIC: {
    EXPLAIN_FROM_TEXT: '/public/explain_from_text',
    SERVER_INFO: '/',
  },
  // 任务状态API
  TASKS: {
    STATUS: '/tasks/status',
  },
  LLM_SUMMARY: {
    DOX_SUMMARY: `/entry-exit/generate-full-report`,
    MAX_SUMMARY: `/entryExit/summary-entrance-comprehensive`,
    TOTAL_FORECAST: `/entryExit/forecast-total`,
    TRAFFIC_TOOLS_FORECAST: `/entryExit/forecast-traffic-tools`,
    TOTAL_FORECAST_HISTORY: `/entryExit/forecast-total/history`,
    TRAFFIC_TOOLS_FORECAST_HISTORY: `/entryExit/forecast-traffic-tools/history`,
    YEAR_DATA_UPLOAD: `/entryExit/year-data/upload`,
    YEAR_DATA_UPLOAD_BATCH: `/entryExit/year-data/upload-batch`,
    YEAR_DATA_IMPORT_JOB: (jobId: string) => `/entryExit/year-data/import-jobs/${encodeURIComponent(jobId)}`,
    YEAR_DATA_IMPORT_JOB_ERRORS: (jobId: string) => `/entryExit/year-data/import-jobs/${encodeURIComponent(jobId)}/errors`,
    YEAR_DATA_IMPORT_JOB_CANCEL: (jobId: string) => `/entryExit/year-data/import-jobs/${encodeURIComponent(jobId)}/cancel`,
    YEAR_DATA_FILES: `/entryExit/year-data/files`,
    YEAR_DATA_FILE_DELETE: (recordId: string | number) => `/entryExit/year-data/files/${encodeURIComponent(String(recordId))}`,
    YEAR_DATA_FILE_DOWNLOAD: (recordId: string | number) => `/entryExit/year-data/files/${encodeURIComponent(String(recordId))}/download`,
    YEAR_DATA_FILE_ACTIVATE: (recordId: string | number) => `/entryExit/year-data/files/${encodeURIComponent(String(recordId))}/activate`,
    YEAR_REPORT_VALIDATE: `/entryExit/year-report/validate`,
    YEAR_REPORT_GENERATE: `/entryExit/year-report/generate`,
    YEAR_REPORT_PROGRESS: (jobId: string) => `/entryExit/year-report/progress/${jobId}`
  },
  // 文档管理接口
  DOCUMENTS: {
    UPLOAD: `/documents/upload`,
    LIST: `/documents`,
    PREVIEW: (filename: string) => `/documents/${encodeURIComponent(filename)}/preview`,
    DOWNLOAD: (filename: string) => `/documents/${encodeURIComponent(filename)}/download`,
    DELETE: (filename: string) => `/documents/${encodeURIComponent(filename)}`
  },
  // 问答日志相关API（使用llmHttp，baseURL已包含/api前缀）
  QA_LOGS: {
    DAILY: `/qa_logs/daily`,           // GET 获取某天的所有日志记录
    DETAIL: `/qa_logs/detail`,         // GET 获取单条日志详情
    DATES: `/qa_logs/dates`,           // GET 获取有日志的日期列表
  },
  // Writing log APIs (llmHttp, baseURL includes /api)
  WRITING_LOGS: {
    DATES: `/writing_logs/dates`,      // GET available writing log dates
    DAILY: `/writing_logs/daily`,      // GET daily writing logs
    DETAIL: `/writing_logs/detail`,    // GET writing log detail
    STATISTICS: `/writing_logs/statistics` // GET writing log statistics
  },

  REPORT_LOGS: {
    LIST: `/logs/report-generation`,                 // GET 获取报告生成日志列表
    DETAIL: (jobId: string) => `/logs/report-generation/${jobId}` // GET 获取单条日志详情
  },
  // 知识库管理API（使用llmHttp，baseURL已包含/api前缀）
  KNOWLEDGE_BASE: {
    VERIFY_PASSWORD: `/knowledge/verify_password`, // POST 校验知识库操作口令
    UPLOAD: `/knowledge/upload`,           // POST 上传文件
    LIST_FILES: `/knowledge/list_files`,   // GET 列出文件
    DELETE_FILE: `/knowledge/delete_file`, // POST 删除文件
    UPDATE_STATUS: `/knowledge/update_status`, // GET 查询更新状态
    IS_UPDATING: `/knowledge/is_updating`, // GET 快速检查更新中
    REBUILD: `/knowledge/rebuild`,         // POST 手动触发重建
  },
  // 视频中心API（使用llmHttp，baseURL已包含/api前缀）
  VIDEOS: {
    LIST: `/videos/list`,                              // GET 获取视频列表
    UPLOAD: `/videos/upload`,                          // POST 上传视频
    INFO: (videoId: string) => `/videos/${videoId}/info`,       // GET 获取视频信息
    DOWNLOAD: (videoId: string) => `/videos/${videoId}/download`, // GET 下载视频
    STREAM: (videoId: string) => `/videos/${videoId}/stream`,    // GET 流式播放
    DELETE: (videoId: string) => `/videos/${videoId}/delete`,    // POST 删除视频
    UPDATE: (videoId: string) => `/videos/${videoId}/update`,    // POST 更新视频信息
  },
  // 用户部门管理API（使用http，baseURL已包含/api前缀）
  USER_DEPARTMENT: {
    GET_USER_DEPARTMENT: `/user/department`,           // GET 获取用户部门信息
    UPDATE_USER_DEPARTMENT: `/user/department`,        // POST 更新用户部门
    GET_DEPARTMENT_LIST: `/departments`,              // GET 获取部门列表
    CHECK_DEPARTMENT_REQUIRED: `/user/department/check` // GET 检查是否需要设置部门
  },
  // 软件管理API（使用http，baseURL已包含/api前缀）
  SOFTWARE: {
    UPLOAD: `/software/upload`,                    // POST 上传软件
    LIST: `/software/list`,                        // GET 获取软件列表
    DOWNLOAD: (filename: string) => `/software/download/${encodeURIComponent(filename)}`,  // GET 下载软件
    DELETE: (filename: string) => `/software/${encodeURIComponent(filename)}`,  // DELETE 删除软件
  }
};

// ===== MCQ 模块端点（合并自 mcq.ts） =====
export const MCQ_ENDPOINTS = {
  UPLOAD: '/upload',
  EXPLAIN: '/explain',
  TASK: { STATUS: '/tasks/status' },
  BANK: {
    LIST: '/bank/list',
    UPSERT: '/bank/bulk_upsert',
    UPDATE: '/bank/bulk_update',
    REJECT: '/bank/bulk_reject',
    EXPORT_DOCX: '/bank/export_docx',
    GENERATE_PAPER: '/bank/generate_paper',
    SOURCES: '/bank/sources',
  },
};


export const getMcqUrl = (path: string): string => {
  if (/^https?:\/\//i.test(path)) return path;
  return `${MCQ_BASE_URL}${path}`;
};

// 本地存储键名
export const STORAGE_KEYS = {
  TOKEN: 'jwt_token',
  CHAT_TOKEN: 'multi_turn_chat_jwt',
  SESSION_ID: 'multi_turn_chat_session_id',
  USER: 'multi_turn_chat_user',
};
